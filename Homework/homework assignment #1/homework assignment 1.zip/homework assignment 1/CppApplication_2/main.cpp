/* 
 * File:   main.cpp
 * Author: Connor Hillis
 *Purpose: First Program
 * Created on June 25, 2014, 4:23 PM
 */

#include <iostream>

using namespace std;

// User Libraries

// Global Constants

// Function Prototypes

// Execute Begins Here
int main(int argc, char** argv) {
    cout<<"Hello World"<< endl;

    return 0;
}

